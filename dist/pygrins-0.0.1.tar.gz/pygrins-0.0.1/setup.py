from distutils.core import setup
setup(
    name = 'pygrins',
    packages = ['pygrins'], # this must be the same as the name above
    version = '0.0.1',
    description = 'Spectral Line Parameter Calculator with emphasis on IGRINS data',
    author = 'Miguel Gutierrez',
    author_email = 'ggmiguel98@gmail.com',
    url = 'https://github.com/mgutierrez32/pygrins',

)
